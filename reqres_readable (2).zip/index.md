| seq | method | status | mime | size | url |
|---:|:--|:--:|:--|--:|:--|
| 2 | GET | 200 | text/javascript | 3695 | chrome-extension://cjpalhdlnbpafiamejdnhcphjbkeiagm/web_accessible_resources/google-analytics_analytics.js?secret=wc1msc |
| 11 | GET | 200 | application/javascript | 0 | https://spodownloader.com/script/axios.min.js |
| 12 | GET | 200 | application/javascript | 0 | https://spodownloader.com/script/index.js |
| 13 | GET | 200 | application/javascript | 0 | https://spodownloader.com/script/index.umd.js |
| 14 | GET | 0 |  | 0 | https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015 |
| 18 | GET | 200 | application/json | 606 | https://api.fabdl.com/spotify/get?url=https%3A%2F%2Fopen.spotify.com%2Ftrack%2F5WOSNVChcadlsCRiqXE45K |
| 20 | GET | 200 | application/json | 572 | https://api.fabdl.com/spotify/mp3-convert-task/16893044/5WOSNVChcadlsCRiqXE45K |
| 21 | GET | 200 | application/json | 568 | https://api.fabdl.com/spotify/mp3-convert-progress/7059fc8b25ad566dd5c90a0b6cb93eea |
